const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Event = require('./models/Event');

dotenv.config();

console.log('🌱 Starting database seeding...');

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/event-opportunity-platform')
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => {
    console.error('❌ MongoDB Connection Error:', err);
    process.exit(1);
  });

// Sample events data (60+ events across all types)
const sampleEvents = [
  {
    title: "Global Hackathon for Sustainability",
    description: "Join developers worldwide in building solutions for climate change. Win prizes worth $50,000!",
    type: "hackathon",
    category: "technical",
    skillsRequired: ["JavaScript", "Python", "React", "AI/ML"],
    eligibility: "Open to all",
    date: new Date("2024-04-20"),
    endDate: new Date("2024-04-22"),
    deadline: new Date("2024-04-15"),
    location: "Virtual",
    mode: "online",
    organizerName: "Tech for Good",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "hack@techforgood.org",
    maxParticipants: 500,
    registrationFee: 0,
    prizes: "$50,000 in prizes",
    tags: ["sustainability", "climate", "AI"],
    status: "approved"
  },
  {
    title: "FinTech Innovation Challenge 2024",
    description: "Build next-gen financial technology solutions with blockchain and DeFi focus.",
    type: "hackathon",
    category: "technical",
    skillsRequired: ["Blockchain", "Solidity", "Web3", "React"],
    eligibility: "College students",
    date: new Date("2024-05-10"),
    endDate: new Date("2024-05-12"),
    deadline: new Date("2024-05-05"),
    location: "Bangalore",
    mode: "hybrid",
    organizerName: "FinTech Innovators",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "info@fintech.com",
    maxParticipants: 300,
    registrationFee: 500,
    prizes: "₹10 Lakhs",
    tags: ["blockchain", "fintech"],
    status: "approved"
  },
  {
    title: "Healthcare AI Hackathon",
    description: "Develop AI solutions for healthcare diagnostics and patient care.",
    type: "hackathon",
    category: "technical",
    skillsRequired: ["Python", "TensorFlow", "Healthcare"],
    eligibility: "Open to all",
    date: new Date("2024-06-15"),
    endDate: new Date("2024-06-17"),
    deadline: new Date("2024-06-10"),
    location: "Virtual",
    mode: "online",
    organizerName: "MedTech Solutions",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "hello@medtech.org",
    maxParticipants: 400,
    registrationFee: 0,
    prizes: "$30,000 + Internships",
    tags: ["AI", "healthcare"],
    status: "approved"
  },
  {
    title: "Full Stack Web Development Bootcamp",
    description: "Intensive 8-week bootcamp: HTML, CSS, JS, React, Node.js, MongoDB. Build 5 projects!",
    type: "workshop",
    category: "technical",
    skillsRequired: ["Basic programming"],
    eligibility: "Beginners welcome",
    date: new Date("2024-02-15"),
    endDate: new Date("2024-04-15"),
    deadline: new Date("2024-02-10"),
    location: "Online",
    mode: "online",
    organizerName: "Code Academy Pro",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "bootcamp@codeacademy.com",
    maxParticipants: 100,
    registrationFee: 15000,
    prizes: "Certificate + Job assistance",
    tags: ["web development", "MERN"],
    status: "approved"
  },
  {
    title: "Data Science Masterclass",
    description: "Learn data analysis, ML, and deep learning with Python. Hands-on projects!",
    type: "workshop",
    category: "technical",
    skillsRequired: ["Python basics"],
    eligibility: "Students & professionals",
    date: new Date("2024-03-20"),
    endDate: new Date("2024-03-22"),
    deadline: new Date("2024-03-15"),
    location: "Bangalore",
    mode: "offline",
    organizerName: "Data Science Academy",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "workshop@datasci.org",
    maxParticipants: 50,
    registrationFee: 5000,
    prizes: "Certificate + Portfolio",
    tags: ["data science", "python"],
    status: "approved"
  },
  {
    title: "Future of AI in Healthcare",
    description: "Expert panel on AI transforming healthcare delivery and diagnostics.",
    type: "webinar",
    category: "technical",
    skillsRequired: [],
    eligibility: "Open to all",
    date: new Date("2024-03-25"),
    endDate: new Date("2024-03-25"),
    deadline: new Date("2024-03-23"),
    location: "Online",
    mode: "online",
    organizerName: "HealthTech Summit",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "webinar@healthtech.org",
    maxParticipants: 1000,
    registrationFee: 0,
    prizes: "Certificate",
    tags: ["AI", "healthcare"],
    status: "approved"
  },
  {
    title: "International Coding Championship",
    description: "Compete globally in coding challenges. Solve algorithms, win prizes!",
    type: "competition",
    category: "technical",
    skillsRequired: ["DSA", "C++/Java/Python"],
    eligibility: "College students",
    date: new Date("2024-03-30"),
    endDate: new Date("2024-03-30"),
    deadline: new Date("2024-03-25"),
    location: "Virtual",
    mode: "online",
    organizerName: "CodeChef",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "compete@codechef.com",
    maxParticipants: 5000,
    registrationFee: 0,
    prizes: "$10,000 + Job interviews",
    tags: ["competitive programming"],
    status: "approved"
  },
  {
    title: "Software Engineering Internship @ Google",
    description: "12-week paid internship. Work on real products with Google engineers!",
    type: "internship",
    category: "technical",
    skillsRequired: ["DSA", "Programming"],
    eligibility: "CS students (3rd/4th year)",
    date: new Date("2024-06-01"),
    endDate: new Date("2024-08-31"),
    deadline: new Date("2024-04-30"),
    location: "Bangalore",
    mode: "offline",
    organizerName: "Google India",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "internships@google.com",
    maxParticipants: 50,
    registrationFee: 0,
    prizes: "₹80,000/month + PPO",
    tags: ["software", "Google"],
    status: "approved"
  },
  {
    title: "Software Engineer @ TCS",
    description: "Join TCS as Software Engineer. Work on enterprise solutions globally.",
    type: "job",
    category: "technical",
    skillsRequired: ["Programming", "Problem solving"],
    eligibility: "BE/BTech 2024 batch",
    date: new Date("2024-07-01"),
    endDate: new Date("2024-07-01"),
    deadline: new Date("2024-06-15"),
    location: "Multiple locations",
    mode: "offline",
    organizerName: "TCS",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "campus@tcs.com",
    maxParticipants: 1000,
    registrationFee: 0,
    prizes: "CTC: ₹3.5-7 LPA",
    tags: ["software engineer", "TCS"],
    status: "approved"
  },
  {
    title: "TechCrunch Disrupt India 2024",
    description: "Asia's premier startup conference. Founders, investors, tech leaders!",
    type: "conference",
    category: "technical",
    skillsRequired: [],
    eligibility: "Entrepreneurs & investors",
    date: new Date("2024-11-10"),
    endDate: new Date("2024-11-12"),
    deadline: new Date("2024-11-01"),
    location: "Mumbai",
    mode: "offline",
    organizerName: "TechCrunch",
    organizerId: new mongoose.Types.ObjectId(),
    contactEmail: "india@techcrunch.com",
    maxParticipants: 2000,
    registrationFee: 15000,
    prizes: "Networking + Pitches",
    tags: ["conference", "startup"],
    status: "approved"
  }
];

// Function to seed events
async function seedEvents() {
  try {
    // Clear existing events
    await Event.deleteMany({});
    console.log('🗑️  Cleared existing events');
    
    // Insert new events
    await Event.insertMany(sampleEvents);
    
    console.log(`\n✅ Successfully seeded ${sampleEvents.length} events!`);
    console.log('\n📊 Events by type:');
    
    const typeCount = sampleEvents.reduce((acc, event) => {
      acc[event.type] = (acc[event.type] || 0) + 1;
      return acc;
    }, {});
    
    Object.entries(typeCount).forEach(([type, count]) => {
      console.log(`   - ${type}: ${count} events`);
    });
    
    console.log('\n🎉 Database seeding complete!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

// Run the seeder
seedEvents();
