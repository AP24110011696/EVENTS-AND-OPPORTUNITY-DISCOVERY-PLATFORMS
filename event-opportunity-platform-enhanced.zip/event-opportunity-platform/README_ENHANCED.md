# 🎉 Event Opportunity Discovery Platform - Enhanced Edition

A stunning, production-ready platform for discovering events, hackathons, workshops, internships, and opportunities!

## ✨ What's New in Enhanced Edition

### 🎨 Modern UI/UX
- **Dark Theme** with gradient accents
- **Glass Morphism** effects
- **Smooth Animations** on all interactions
- **Gradient Buttons** and badges
- **Professional Card Designs** with hover effects

### 📊 Rich Sample Data  
- **60+ Pre-loaded Events** across all categories
- **Realistic Event Details** with prizes, locations, dates
- **Diverse Event Types**: Hackathons, Workshops, Webinars, Competitions, Internships, Jobs, Conferences

### 🔥 Enhanced Features
- **Advanced Filtering** by type, mode, and keywords
- **Real-time Search** with instant results
- **Event Categories** with color coding
- **Status Badges** for approved/pending events
- **Responsive Design** for all devices

## 🚀 Quick Start

### Installation

```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies  
cd ../frontend
npm install
```

### Setup & Run

```bash
# 1. Setup environment
cd backend
cp .env.example .env
# Edit .env with your MongoDB URI

# 2. Seed sample events
node seedEvents.js

# 3. Start backend (Terminal 1)
npm start

# 4. Start frontend (Terminal 2)
cd ../frontend
npm start
```

Visit http://localhost:3000 🎊

## 📸 Screenshots

The enhanced platform features:
- 🌙 Beautiful dark mode interface
- 🎨 Gradient color scheme (Blue #2563EB → Purple #7C3AED)
- ✨ Smooth hover animations
- 🎯 Clean, modern card layouts
- 📱 Mobile-responsive design

## 🎯 Event Categories

### Hackathons (10 Events)
- Global Sustainability Hackathon
- FinTech Innovation Challenge
- Healthcare AI Hackathon
- Game Dev Jam
- And 6 more...

### Workshops (10 Events)
- Full Stack Web Development Bootcamp
- Data Science Masterclass
- UI/UX Design Workshop
- Cloud Computing with AWS
- And 6 more...

### Webinars (10 Events)
- Future of AI in Healthcare
- Career in Data Science AMA
- Blockchain & Crypto Trends
- Women in Tech Leadership
- And 6 more...

### Competitions (10 Events)
- International Coding Championship
- UI/UX Design Battle
- Startup Pitch Competition
- Data Science Challenge
- And 6 more...

### Internships (10 Events)
- Software Engineering @ Google
- Data Science @ Amazon
- Product Management @ Microsoft
- UI/UX Design @ Adobe
- And 6 more...

### Jobs (10 Events)
- Software Engineer @ TCS
- Data Analyst @ Accenture
- Frontend Developer @ Razorpay
- DevOps Engineer @ Infosys
- And 6 more...

### Conferences (5 Events)
- TechCrunch Disrupt India
- PyCon India
- AWS re:Invent India
- Grace Hopper Celebration
- India AI Summit

## 🛠 Tech Stack

**Frontend:**
- React 18
- React Router v6
- Axios
- React Icons
- CSS3 (Modern features)

**Backend:**
- Node.js
- Express.js
- MongoDB & Mongoose
- JWT Authentication
- Bcrypt

## 📱 Features

### For Students
✅ Browse 60+ events
✅ Filter by type, mode, skills
✅ Search functionality
✅ Register for events
✅ Track registrations
✅ Personal dashboard

### For Organizers
✅ Create & manage events
✅ View registered participants
✅ Update event details
✅ Track event analytics

### For Admins
✅ Approve/reject events
✅ Manage users
✅ Platform statistics
✅ System monitoring

## 🎨 Color Scheme

```css
Primary Blue: #2563EB
Primary Dark: #1E40AF
Purple Accent: #7C3AED
Success Green: #10B981
Warning Yellow: #F59E0B
Danger Red: #EF4444
Info Cyan: #06B6D4

Dark Background: #0F172A
Dark Card: #1E293B
Dark Border: #334155
Text Primary: #F1F5F9
Text Secondary: #94A3B8
```

## 📖 Documentation

- `README.md` - Main documentation
- `SETUP_GUIDE.md` - Detailed setup instructions
- `ENHANCEMENT_INSTRUCTIONS.md` - UI enhancement guide
- `UI_ENHANCEMENT_QUICK_START.md` - Quick start for UI
- `PROJECT_STRUCTURE.txt` - File organization

## 🚀 Deployment

### Backend (Render/Heroku)
1. Create account
2. Connect repository
3. Set environment variables
4. Deploy

### Frontend (Vercel/Netlify)  
1. Connect repository
2. Build command: `npm run build`
3. Publish directory: `build`
4. Deploy

### Database (MongoDB Atlas)
1. Create cluster
2. Get connection string
3. Update MONGODB_URI

## 🤝 Contributing

This is an academic project. Feel free to fork and enhance!

## 📝 License

MIT License - Feel free to use for learning!

## 👨‍💻 Developer

**Nithin**  
B.Tech Computer Science Engineering Student  
Final Year Project

---

**Made with ❤️ using MERN Stack**

🌟 Star this project if you find it helpful!
