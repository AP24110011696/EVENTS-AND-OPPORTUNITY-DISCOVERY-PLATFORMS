# Event Discovery Platform - UI/UX Enhancement Guide

This document contains instructions to enhance your existing Event Opportunity Discovery Platform with a modern, attractive UI inspired by the reference designs.

## Color Scheme (Based on Reference Images)

### Primary Colors
- **Primary Blue**: #2563EB
- **Dark Blue**: #1E40AF  
- **Purple Accent**: #7C3AED
- **Dark Background**: #0F172A
- **Card Background**: #1E293B

### Secondary Colors
- **Success Green**: #10B981
- **Warning Yellow**: #F59E0B
- **Danger Red**: #EF4444
- **Info Cyan**: #06B6D4

## Frontend Enhancements

### 1. Update App.css with Modern Theme

Replace the existing `/frontend/src/App.css` with:

```css
:root {
  --primary: #2563EB;
  --primary-dark: #1E40AF;
  --secondary: #7C3AED;
  --success: #10B981;
  --warning: #F59E0B;
  --danger: #EF4444;
  --info: #06B6D4;
  
  --dark-bg: #0F172A;
  --dark-card: #1E293B;
  --dark-border: #334155;
  --text-primary: #F1F5F9;
  --text-secondary: #94A3B8;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
  background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
  color: var(--text-primary);
  min-height: 100vh;
}

.App {
  min-height: 100vh;
}

/* Modern Card Design */
.card {
  background: var(--dark-card);
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  border: 1px solid var(--dark-border);
  transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 40px rgba(37, 99, 235, 0.2);
}

/* Gradient Buttons */
.btn-primary {
  background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
  color: white;
  padding: 12px 28px;
  border: none;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4);
}

/* Modern Badges */
.badge {
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.badge-primary {
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  color: white;
}

.badge-success {
  background: linear-gradient(135deg, #10B981 0%, #059669 100%);
  color: white;
}

/* Glass Morphism Effect */
.glass {
  background: rgba(30, 41, 59, 0.7);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
}

/* Animated Gradient Text */
.gradient-text {
  background: linear-gradient(135deg, #3B82F6, #8B5CF6, #EC4899);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* Search Bar Modern Design */
.search-container {
  position: relative;
  max-width: 600px;
  margin: 0 auto;
}

.search-input {
  width: 100%;
  padding: 16px 50px 16px 20px;
  background: var(--dark-card);
  border: 2px solid var(--dark-border);
  border-radius: 50px;
  color: var(--text-primary);
  font-size: 16px;
  transition: all 0.3s;
}

.search-input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
}

/* Loading Animation */
.loading {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 20px;
  color: var(--text-secondary);
}

.loading::after {
  content: '';
  width: 40px;
  height: 40px;
  margin-left: 15px;
  border: 4px solid var(--dark-border);
  border-top-color: var(--primary);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* Responsive Grid */
.events-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 24px;
  margin-top: 30px;
}

@media (max-width: 768px) {
  .events-grid {
    grid-template-columns: 1fr;
  }
}
```

### 2. Enhanced Events Page

Update `/frontend/src/pages/Events.css`:

```css
.events-page {
  min-height: 100vh;
  padding: 40px 20px;
  background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
}

.events-header {
  text-align: center;
  margin-bottom: 50px;
}

.events-header h1 {
  font-size: 48px;
  font-weight: 800;
  background: linear-gradient(135deg, #3B82F6, #8B5CF6, #EC4899);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 15px;
}

.filters-section {
  background: rgba(30, 41, 59, 0.5);
  backdrop-filter: blur(10px);
  padding: 30px;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  margin-bottom: 40px;
}

.filter-grid {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 20px;
}

@media (max-width: 768px) {
  .filter-grid {
    grid-template-columns: 1fr;
  }
}

.event-card {
  background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: all 0.3s;
  position: relative;
}

.event-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #3B82F6, #8B5CF6, #EC4899);
}

.event-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 40px rgba(37, 99, 235, 0.3);
  border-color: rgba(59, 130, 246, 0.5);
}

.event-card-image {
  height: 180px;
  background: linear-gradient(135deg, #3B82F6, #8B5CF6);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 48px;
  color: white;
}

.event-card-content {
  padding: 24px;
}

.event-title {
  font-size: 20px;
  font-weight: 700;
  color: #F1F5F9;
  margin-bottom: 12px;
  line-height: 1.4;
}

.event-description {
  color: #94A3B8;
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 16px;
}

.event-meta {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 20px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #CBD5E1;
  font-size: 14px;
}

.meta-item svg {
  color: #3B82F6;
  flex-shrink: 0;
}

.event-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 16px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.event-badges {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.view-btn {
  padding: 10px 20px;
  background: linear-gradient(135deg, #2563EB 0%, #7C3AED 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
  text-decoration: none;
  display: inline-block;
}

.view-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4);
}
```

### 3. Backend Seed Data

Create a file `/backend/seedEvents.js`:

```javascript
// Run this after starting your backend: node seedEvents.js
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Event = require('./models/Event');

dotenv.config();

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

const events = [
  // ... paste the events from the seedData.js file created earlier
];

Event.deleteMany({})
  .then(() => Event.insertMany(events))
  .then(() => {
    console.log('✅ Events seeded successfully!');
    process.exit(0);
  })
  .catch(err => {
    console.error('❌ Error:', err);
    process.exit(1);
  });
```

## Implementation Steps

1. **Update Styling**:
   - Replace App.css with the modern theme
   - Update Events.css with new card designs
   - Update other component CSS files similarly

2. **Add Icons**:
   - The project already uses react-icons
   - Import icons: `import { FaCalendar, FaMapMarkerAlt, FaClock, FaUsers } from 'react-icons/fa'`

3. **Seed Database**:
   ```bash
   cd backend
   node seedEvents.js
   ```

4. **Test**:
   - Start backend: `npm start`
   - Start frontend: `npm start`
   - Browse events page to see the enhanced UI

## Additional Enhancements

### Add Event Counters
In Events page, add stats:
```javascript
<div className="stats-grid">
  <div className="stat-card">
    <h3>{events.length}</h3>
    <p>Total Events</p>
  </div>
  {/* Add more stats */}
</div>
```

### Add Skeleton Loading
While events load, show skeleton cards for better UX.

### Add Empty State
When no events match filters, show friendly message with call-to-action.

## Reference Images Analysis

Your reference images show:
1. **Dark theme** with blue/purple gradients ✅
2. **Dropdown filters** for event types/modes ✅
3. **Clean card layouts** with clear CTAs ✅
4. **Modern typography** and spacing ✅
5. **Status badges** and icons ✅

All these elements are incorporated in the enhancement guide above!
