# Setup Guide - Event Opportunity Discovery Platform

This guide will help you set up and run the Event Opportunity Discovery Platform on your local machine.

## Prerequisites Checklist

Before starting, make sure you have:
- [ ] Node.js installed (version 14 or higher)
- [ ] MongoDB installed and running
- [ ] A code editor (VS Code recommended)
- [ ] Git (optional, for version control)
- [ ] Basic knowledge of terminal/command prompt

## Step-by-Step Setup

### Step 1: Install Node.js

1. Visit https://nodejs.org/
2. Download the LTS version for your operating system
3. Install Node.js
4. Verify installation:
```bash
node --version
npm --version
```

### Step 2: Install MongoDB

#### On Windows:
1. Download MongoDB Community Server from https://www.mongodb.com/try/download/community
2. Run the installer
3. Choose "Complete" installation
4. Install MongoDB as a Service
5. Install MongoDB Compass (GUI tool)

#### On macOS:
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

#### On Linux (Ubuntu):
```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

Verify MongoDB installation:
```bash
mongod --version
```

### Step 3: Extract and Navigate to Project

1. Extract the project ZIP file
2. Open terminal/command prompt
3. Navigate to the project directory:
```bash
cd path/to/event-opportunity-platform
```

### Step 4: Setup Backend

1. Navigate to backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create environment file:
```bash
# On Windows
copy .env.example .env

# On Mac/Linux
cp .env.example .env
```

4. Open `.env` file and update values:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/event-opportunity-platform
JWT_SECRET=my_super_secret_key_12345
JWT_EXPIRE=7d
NODE_ENV=development
```

5. Start the backend server:
```bash
npm start
```

You should see:
```
Server running on port 5000
MongoDB Connected: localhost
```

### Step 5: Setup Frontend

1. Open a new terminal window
2. Navigate to frontend directory:
```bash
cd path/to/event-opportunity-platform/frontend
```

3. Install dependencies:
```bash
npm install
```

4. Start the development server:
```bash
npm start
```

Your browser should automatically open http://localhost:3000

### Step 6: Verify Setup

1. Backend should be running on http://localhost:5000
2. Frontend should be running on http://localhost:3000
3. Open http://localhost:3000 in your browser
4. You should see the Event Discovery Platform homepage

## Testing the Application

### Create a Test Account

1. Click "Register" on the homepage
2. Fill in the registration form:
   - Name: Test User
   - Email: test@example.com
   - Password: password123
   - Role: Student
   - College: Your College Name
   - Skills: JavaScript, Python
   - Interests: Web Development, AI

3. Click "Register"
4. You'll be redirected to login
5. Login with your credentials

### Create an Organizer Account

1. Register another account with role "Organizer"
2. This account can create events

### Create Admin Account (Manual Database Setup)

Since there's no UI for creating admin accounts, you need to create one via MongoDB:

#### Using MongoDB Compass:
1. Open MongoDB Compass
2. Connect to mongodb://localhost:27017
3. Select `event-opportunity-platform` database
4. Select `users` collection
5. Find your user document
6. Click Edit
7. Change `role` from "student" to "admin"
8. Save

#### Using MongoDB Shell:
```bash
mongosh
use event-opportunity-platform
db.users.updateOne(
  { email: "test@example.com" },
  { $set: { role: "admin" } }
)
```

## Common Issues and Solutions

### Issue 1: MongoDB Connection Failed

**Error:** `MongooseServerSelectionError: connect ECONNREFUSED`

**Solution:**
- Make sure MongoDB is running
- Windows: Check Services for MongoDB
- Mac/Linux: Run `sudo systemctl status mongod`
- Try restarting MongoDB service

### Issue 2: Port Already in Use

**Error:** `EADDRINUSE: address already in use :::5000`

**Solution:**
- Change PORT in backend/.env to 5001 or another available port
- Update API_URL in frontend/src/utils/api.js accordingly

### Issue 3: npm install fails

**Error:** Various npm errors

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

### Issue 4: CORS Error in Browser

**Error:** `Access to XMLHttpRequest has been blocked by CORS policy`

**Solution:**
- Make sure backend server is running
- Check that cors is installed in backend
- Verify API_URL in frontend matches backend URL

### Issue 5: JWT Token Invalid

**Error:** `Not authorized to access this route`

**Solution:**
- Clear browser localStorage
- Login again
- Make sure JWT_SECRET matches in .env

## Development Workflow

### Starting Development

1. Open two terminal windows
2. Terminal 1 (Backend):
```bash
cd backend
npm start
```

3. Terminal 2 (Frontend):
```bash
cd frontend
npm start
```

### Making Changes

- Backend changes: Server auto-restarts with nodemon
- Frontend changes: Browser auto-refreshes
- Database changes: Use MongoDB Compass or shell

### Stopping the Application

- Press `Ctrl+C` in both terminal windows
- MongoDB will continue running in background (which is fine)

## Next Steps

1. ✅ Application is running
2. ✅ Create test accounts
3. ✅ Create sample events
4. ✅ Test registration functionality
5. ✅ Explore admin panel features

## Production Deployment

For production deployment instructions, refer to the DEPLOYMENT_GUIDE.md file.

## Getting Help

If you encounter issues:
1. Check this guide's "Common Issues" section
2. Review error messages carefully
3. Check browser console for frontend errors
4. Check terminal for backend errors
5. Verify MongoDB is running

## Additional Resources

- Node.js Documentation: https://nodejs.org/docs
- MongoDB Documentation: https://docs.mongodb.com
- React Documentation: https://react.dev
- Express.js Documentation: https://expressjs.com

---

Happy Coding! 🚀
