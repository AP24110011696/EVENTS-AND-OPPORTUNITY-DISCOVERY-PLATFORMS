const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide an event title'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Please provide an event description']
  },
  type: {
    type: String,
    required: true,
    enum: ['hackathon', 'workshop', 'webinar', 'competition', 'internship', 'job', 'conference', 'other']
  },
  category: {
    type: String,
    enum: ['technical', 'non-technical', 'sports', 'cultural', 'academic']
  },
  skillsRequired: [{
    type: String,
    trim: true
  }],
  eligibility: {
    type: String
  },
  date: {
    type: Date,
    required: [true, 'Please provide event date']
  },
  endDate: {
    type: Date
  },
  deadline: {
    type: Date
  },
  location: {
    type: String,
    required: [true, 'Please provide location']
  },
  mode: {
    type: String,
    enum: ['online', 'offline', 'hybrid'],
    default: 'offline'
  },
  organizerName: {
    type: String,
    required: true
  },
  organizerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  contactEmail: {
    type: String,
    required: true
  },
  contactPhone: {
    type: String
  },
  maxParticipants: {
    type: Number,
    default: 0
  },
  registrationFee: {
    type: Number,
    default: 0
  },
  prizes: {
    type: String
  },
  websiteUrl: {
    type: String
  },
  imageUrl: {
    type: String,
    default: 'default-event.jpg'
  },
  tags: [{
    type: String
  }],
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'completed'],
    default: 'pending'
  },
  registeredUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Index for search functionality
eventSchema.index({ title: 'text', description: 'text', tags: 'text' });

module.exports = mongoose.model('Event', eventSchema);
