const express = require('express');
const router = express.Router();
const {
  registerForEvent,
  cancelRegistration,
  getMyRegistrations,
  getEventRegistrations
} = require('../controllers/registrationController');
const { protect, authorize } = require('../middleware/auth');

router.get('/myregistrations', protect, getMyRegistrations);
router.get('/event/:eventId', protect, authorize('organizer', 'admin'), getEventRegistrations);
router.post('/:eventId', protect, registerForEvent);
router.delete('/:eventId', protect, cancelRegistration);

module.exports = router;
