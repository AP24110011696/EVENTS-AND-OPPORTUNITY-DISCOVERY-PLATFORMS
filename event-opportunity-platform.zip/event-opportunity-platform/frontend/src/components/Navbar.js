import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { FaUser, FaSignOutAlt, FaCalendarAlt, FaTachometerAlt } from 'react-icons/fa';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <FaCalendarAlt /> EventHub
        </Link>

        <ul className="navbar-menu">
          <li><Link to="/events">Events</Link></li>
          
          {user ? (
            <>
              <li><Link to="/dashboard"><FaTachometerAlt /> Dashboard</Link></li>
              
              {(user.role === 'organizer' || user.role === 'admin') && (
                <>
                  <li><Link to="/create-event">Create Event</Link></li>
                  <li><Link to="/my-events">My Events</Link></li>
                </>
              )}
              
              {user.role === 'admin' && (
                <li><Link to="/admin">Admin Panel</Link></li>
              )}
              
              <li className="navbar-user">
                <span><FaUser /> {user.name}</span>
                <div className="dropdown-menu">
                  <Link to="/profile">Profile</Link>
                  <Link to="/my-registrations">My Registrations</Link>
                  <button onClick={handleLogout}><FaSignOutAlt /> Logout</button>
                </div>
              </li>
            </>
          ) : (
            <>
              <li><Link to="/login" className="btn-nav">Login</Link></li>
              <li><Link to="/register" className="btn-nav btn-nav-primary">Register</Link></li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
