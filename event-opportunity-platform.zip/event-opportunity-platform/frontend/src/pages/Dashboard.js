import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { FaCalendarAlt, FaUser, FaPlus, FaList } from 'react-icons/fa';
import './Dashboard.css';

const Dashboard = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="dashboard container">
      <h1>Welcome back, {user?.name}!</h1>
      <p className="dashboard-subtitle">Manage your events and registrations from here</p>

      <div className="dashboard-grid">
        <Link to="/events" className="dashboard-card">
          <FaCalendarAlt className="dashboard-icon" />
          <h3>Browse Events</h3>
          <p>Discover new events and opportunities</p>
        </Link>

        <Link to="/my-registrations" className="dashboard-card">
          <FaList className="dashboard-icon" />
          <h3>My Registrations</h3>
          <p>View your registered events</p>
        </Link>

        <Link to="/profile" className="dashboard-card">
          <FaUser className="dashboard-icon" />
          <h3>Profile</h3>
          <p>Update your profile information</p>
        </Link>

        {(user?.role === 'organizer' || user?.role === 'admin') && (
          <>
            <Link to="/create-event" className="dashboard-card">
              <FaPlus className="dashboard-icon" />
              <h3>Create Event</h3>
              <p>Post a new event or opportunity</p>
            </Link>

            <Link to="/my-events" className="dashboard-card">
              <FaList className="dashboard-icon" />
              <h3>My Events</h3>
              <p>Manage your posted events</p>
            </Link>
          </>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
