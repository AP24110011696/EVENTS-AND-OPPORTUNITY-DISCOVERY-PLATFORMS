import React from 'react';

const Profile = () => {
  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <h1>Profile</h1>
      <p>This page is under construction. Please implement the full functionality.</p>
    </div>
  );
};

export default Profile;
