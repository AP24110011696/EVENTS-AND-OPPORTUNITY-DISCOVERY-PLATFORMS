import React from 'react';

const MyRegistrations = () => {
  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <h1>MyRegistrations</h1>
      <p>This page is under construction. Please implement the full functionality.</p>
    </div>
  );
};

export default MyRegistrations;
