import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { FaRocket, FaUsers, FaCalendarCheck, FaSearch } from 'react-icons/fa';
import './Home.css';

const Home = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-content">
          <h1>Discover Events & Opportunities</h1>
          <p>Your centralized platform for hackathons, workshops, internships, and more</p>
          <div className="hero-buttons">
            {user ? (
              <Link to="/events" className="btn btn-primary btn-large">Browse Events</Link>
            ) : (
              <>
                <Link to="/register" className="btn btn-primary btn-large">Get Started</Link>
                <Link to="/events" className="btn btn-outline btn-large">Explore Events</Link>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2 className="section-title">Why Choose EventHub?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <FaSearch />
              </div>
              <h3>Easy Discovery</h3>
              <p>Find events based on your interests, skills, and career goals with advanced search and filters</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaCalendarCheck />
              </div>
              <h3>Centralized Platform</h3>
              <p>All events, hackathons, and opportunities in one place. No more missing out on great opportunities</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaUsers />
              </div>
              <h3>For Everyone</h3>
              <p>Students can discover and register, organizers can post events, and admins can manage the platform</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <FaRocket />
              </div>
              <h3>Track Progress</h3>
              <p>Keep track of all your registrations and upcoming events in your personalized dashboard</p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container">
          <h2>Ready to Start Your Journey?</h2>
          <p>Join thousands of students discovering amazing opportunities every day</p>
          {!user && (
            <Link to="/register" className="btn btn-primary btn-large">Create Account</Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;
