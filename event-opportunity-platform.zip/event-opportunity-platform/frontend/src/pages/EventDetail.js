import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import api from '../utils/api';
import { toast } from 'react-toastify';
import './EventDetail.css';

const EventDetail = () => {
  const { id } = useParams();
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);

  useEffect(() => {
    fetchEvent();
  }, [id]);

  const fetchEvent = async () => {
    try {
      const res = await api.get(`/events/${id}`);
      setEvent(res.data.event);
      setLoading(false);
    } catch (error) {
      toast.error('Failed to fetch event details');
      setLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!user) {
      toast.info('Please login to register');
      navigate('/login');
      return;
    }

    setRegistering(true);
    try {
      await api.post(`/registrations/${id}`);
      toast.success('Successfully registered for the event!');
      fetchEvent();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Registration failed');
    } finally {
      setRegistering(false);
    }
  };

  if (loading) return <div className="loading">Loading event details...</div>;
  if (!event) return <div className="loading">Event not found</div>;

  const isRegistered = user && event.registeredUsers?.some(u => u._id === user.id);

  return (
    <div className="event-detail-page container">
      <div className="event-detail-card card">
        <h1>{event.title}</h1>
        
        <div className="event-badges">
          <span className="badge badge-primary">{event.type}</span>
          <span className="badge badge-info">{event.mode}</span>
          <span className="badge badge-success">{event.status}</span>
        </div>

        <div className="event-info">
          <div className="info-item">
            <strong>Organizer:</strong> {event.organizerName}
          </div>
          <div className="info-item">
            <strong>Date:</strong> {new Date(event.date).toLocaleString()}
          </div>
          <div className="info-item">
            <strong>Location:</strong> {event.location}
          </div>
          <div className="info-item">
            <strong>Mode:</strong> {event.mode}
          </div>
          {event.maxParticipants > 0 && (
            <div className="info-item">
              <strong>Spots:</strong> {event.registeredUsers?.length || 0}/{event.maxParticipants}
            </div>
          )}
        </div>

        <div className="event-description-section">
          <h3>Description</h3>
          <p>{event.description}</p>
        </div>

        {event.skillsRequired?.length > 0 && (
          <div className="event-skills">
            <h3>Skills Required</h3>
            <div className="skills-list">
              {event.skillsRequired.map((skill, idx) => (
                <span key={idx} className="badge badge-primary">{skill}</span>
              ))}
            </div>
          </div>
        )}

        {event.eligibility && (
          <div className="event-eligibility">
            <h3>Eligibility</h3>
            <p>{event.eligibility}</p>
          </div>
        )}

        {user && event.status === 'approved' && (
          <div className="event-actions">
            {isRegistered ? (
              <button className="btn btn-success" disabled>Already Registered</button>
            ) : (
              <button 
                className="btn btn-primary" 
                onClick={handleRegister}
                disabled={registering}
              >
                {registering ? 'Registering...' : 'Register for Event'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default EventDetail;
