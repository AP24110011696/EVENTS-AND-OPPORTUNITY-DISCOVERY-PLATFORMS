import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { toast } from 'react-toastify';
import { FaCalendar, FaMapMarkerAlt, FaSearch } from 'react-icons/fa';
import './Events.css';

const Events = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    type: '',
    mode: '',
    search: ''
  });

  useEffect(() => {
    fetchEvents();
  }, [filters]);

  const fetchEvents = async () => {
    try {
      const queryParams = new URLSearchParams();
      if (filters.type) queryParams.append('type', filters.type);
      if (filters.mode) queryParams.append('mode', filters.mode);
      if (filters.search) queryParams.append('search', filters.search);

      const res = await api.get(`/events?${queryParams.toString()}`);
      setEvents(res.data.events);
      setLoading(false);
    } catch (error) {
      toast.error('Failed to fetch events');
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  if (loading) return <div className="loading">Loading events...</div>;

  return (
    <div className="events-page container">
      <h1>Discover Events & Opportunities</h1>

      <div className="filters-section card">
        <div className="filter-group">
          <FaSearch />
          <input
            type="text"
            name="search"
            placeholder="Search events..."
            className="form-control"
            value={filters.search}
            onChange={handleFilterChange}
          />
        </div>

        <select name="type" className="form-control" value={filters.type} onChange={handleFilterChange}>
          <option value="">All Types</option>
          <option value="hackathon">Hackathon</option>
          <option value="workshop">Workshop</option>
          <option value="webinar">Webinar</option>
          <option value="competition">Competition</option>
          <option value="internship">Internship</option>
          <option value="job">Job</option>
        </select>

        <select name="mode" className="form-control" value={filters.mode} onChange={handleFilterChange}>
          <option value="">All Modes</option>
          <option value="online">Online</option>
          <option value="offline">Offline</option>
          <option value="hybrid">Hybrid</option>
        </select>
      </div>

      <div className="events-grid">
        {events.length > 0 ? (
          events.map(event => (
            <div key={event._id} className="event-card">
              <div className="event-header">
                <h3>{event.title}</h3>
                <span className={`badge badge-${event.type}`}>{event.type}</span>
              </div>
              
              <p className="event-description">{event.description.substring(0, 120)}...</p>
              
              <div className="event-details">
                <div className="event-detail">
                  <FaCalendar /> {new Date(event.date).toLocaleDateString()}
                </div>
                <div className="event-detail">
                  <FaMapMarkerAlt /> {event.location}
                </div>
              </div>

              <div className="event-footer">
                <span className="badge badge-info">{event.mode}</span>
                <Link to={`/events/${event._id}`} className="btn btn-primary btn-sm">View Details</Link>
              </div>
            </div>
          ))
        ) : (
          <p className="no-events">No events found matching your criteria.</p>
        )}
      </div>
    </div>
  );
};

export default Events;
