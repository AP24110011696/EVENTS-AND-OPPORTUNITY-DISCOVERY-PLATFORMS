# Event Opportunity Discovery Platform

A centralized web platform for discovering and managing events, hackathons, workshops, internships, and opportunities. Built with MERN stack (MongoDB, Express.js, React, Node.js).

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [API Documentation](#api-documentation)
- [User Roles](#user-roles)
- [Database Schema](#database-schema)
- [Screenshots](#screenshots)
- [Future Enhancements](#future-enhancements)

## ✨ Features

### For Students
- Browse and search events by type, category, location, and skills
- Register for events and track registrations
- Personalized dashboard with upcoming events
- Profile management with skills and interests
- Filter events based on preferences

### For Organizers
- Create and manage events
- View registered participants
- Track event analytics
- Update event details

### For Admins
- Approve/reject events
- Manage users and organizers
- View platform statistics
- Monitor all activities

## 🛠 Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **JWT** - Authentication
- **bcrypt** - Password hashing
- **express-validator** - Input validation

### Frontend
- **React** - UI library
- **React Router** - Navigation
- **Axios** - HTTP client
- **React Icons** - Icons
- **React Toastify** - Notifications
- **CSS3** - Styling

## 📁 Project Structure

```
event-opportunity-platform/
├── backend/
│   ├── config/
│   │   └── db.js                 # Database configuration
│   ├── controllers/
│   │   ├── authController.js     # Authentication logic
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js
│   │   └── adminController.js    # Admin operations
│   ├── middleware/
│   │   └── auth.js               # JWT verification
│   ├── models/
│   │   ├── User.js               # User schema
│   │   ├── Event.js              # Event schema
│   │   └── Registration.js       # Registration schema
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── eventRoutes.js
│   │   ├── registrationRoutes.js
│   │   └── adminRoutes.js
│   ├── .env.example
│   ├── package.json
│   └── server.js                 # Entry point
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── Navbar.js
    │   │   ├── Navbar.css
    │   │   └── PrivateRoute.js
    │   ├── context/
    │   │   └── AuthContext.js    # Global state
    │   ├── pages/
    │   │   ├── Home.js
    │   │   ├── Login.js
    │   │   ├── Register.js
    │   │   ├── Events.js
    │   │   ├── EventDetail.js
    │   │   ├── Dashboard.js
    │   │   ├── CreateEvent.js
    │   │   ├── MyEvents.js
    │   │   ├── MyRegistrations.js
    │   │   ├── Profile.js
    │   │   └── AdminDashboard.js
    │   ├── utils/
    │   │   └── api.js            # Axios configuration
    │   ├── App.js
    │   ├── App.css
    │   ├── index.js
    │   └── index.css
    └── package.json
```

## 📦 Prerequisites

Before you begin, ensure you have the following installed:
- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn package manager

## 🚀 Installation

### 1. Clone the repository

```bash
git clone <repository-url>
cd event-opportunity-platform
```

### 2. Install Backend Dependencies

```bash
cd backend
npm install
```

### 3. Install Frontend Dependencies

```bash
cd ../frontend
npm install
```

## ⚙️ Configuration

### Backend Configuration

1. Create a `.env` file in the `backend` directory:

```bash
cd backend
cp .env.example .env
```

2. Update the `.env` file with your configuration:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/event-opportunity-platform
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRE=7d
NODE_ENV=development
```

### Frontend Configuration

If your backend runs on a different port, update the API_URL in:
- `frontend/src/utils/api.js`
- `frontend/src/context/AuthContext.js`

## 🏃 Running the Application

### Method 1: Run Separately

#### Start MongoDB
```bash
# On Linux/Mac
sudo systemctl start mongod

# On Windows
net start MongoDB
```

#### Start Backend Server
```bash
cd backend
npm start
# Server runs on http://localhost:5000
```

#### Start Frontend Development Server
```bash
cd frontend
npm start
# App runs on http://localhost:3000
```

### Method 2: Run Concurrently

You can install `concurrently` to run both servers with one command:

```bash
npm install -g concurrently
```

Create a script in root package.json:
```json
{
  "scripts": {
    "start": "concurrently \"cd backend && npm start\" \"cd frontend && npm start\""
  }
}
```

Then run:
```bash
npm start
```

## 📚 API Documentation

### Authentication Routes

#### Register User
```
POST /api/auth/register
Body: {
  name, email, password, role, skills, interests, college, branch, year, phone
}
```

#### Login
```
POST /api/auth/login
Body: { email, password }
```

#### Get Current User
```
GET /api/auth/me
Headers: { Authorization: "Bearer <token>" }
```

#### Update Profile
```
PUT /api/auth/updateprofile
Headers: { Authorization: "Bearer <token>" }
Body: { name, skills, interests, college, branch, year, phone, bio }
```

### Event Routes

#### Get All Events
```
GET /api/events?type=<type>&mode=<mode>&search=<query>
```

#### Get Single Event
```
GET /api/events/:id
```

#### Create Event (Organizer/Admin)
```
POST /api/events
Headers: { Authorization: "Bearer <token>" }
Body: {
  title, description, type, skillsRequired, date, location, mode, etc.
}
```

#### Update Event (Organizer/Admin)
```
PUT /api/events/:id
Headers: { Authorization: "Bearer <token>" }
```

#### Delete Event (Organizer/Admin)
```
DELETE /api/events/:id
Headers: { Authorization: "Bearer <token>" }
```

#### Approve Event (Admin)
```
PUT /api/events/:id/approve
Headers: { Authorization: "Bearer <token>" }
```

#### Reject Event (Admin)
```
PUT /api/events/:id/reject
Headers: { Authorization: "Bearer <token>" }
```

### Registration Routes

#### Register for Event
```
POST /api/registrations/:eventId
Headers: { Authorization: "Bearer <token>" }
```

#### Cancel Registration
```
DELETE /api/registrations/:eventId
Headers: { Authorization: "Bearer <token>" }
```

#### Get My Registrations
```
GET /api/registrations/myregistrations
Headers: { Authorization: "Bearer <token>" }
```

#### Get Event Registrations (Organizer/Admin)
```
GET /api/registrations/event/:eventId
Headers: { Authorization: "Bearer <token>" }
```

### Admin Routes

#### Get All Users
```
GET /api/admin/users
Headers: { Authorization: "Bearer <token>" }
```

#### Get Dashboard Stats
```
GET /api/admin/stats
Headers: { Authorization: "Bearer <token>" }
```

#### Get Pending Events
```
GET /api/admin/events/pending
Headers: { Authorization: "Bearer <token>" }
```

## 👥 User Roles

### Student
- Default role for new users
- Can browse and register for events
- Can manage their profile and registrations

### Organizer
- Can create and manage events
- View registered participants
- All student permissions

### Admin
- Full platform access
- Approve/reject events
- Manage users
- View analytics
- All organizer permissions

## 🗄️ Database Schema

### User Schema
```javascript
{
  name: String (required),
  email: String (required, unique),
  password: String (required, hashed),
  role: String (enum: ['student', 'organizer', 'admin']),
  skills: [String],
  interests: [String],
  college: String,
  branch: String,
  year: String,
  phone: String,
  bio: String,
  profileImage: String,
  createdAt: Date
}
```

### Event Schema
```javascript
{
  title: String (required),
  description: String (required),
  type: String (enum: hackathon, workshop, webinar, etc.),
  category: String,
  skillsRequired: [String],
  eligibility: String,
  date: Date (required),
  endDate: Date,
  deadline: Date,
  location: String (required),
  mode: String (enum: online, offline, hybrid),
  organizerName: String,
  organizerId: ObjectId (ref: User),
  contactEmail: String,
  contactPhone: String,
  maxParticipants: Number,
  registrationFee: Number,
  prizes: String,
  websiteUrl: String,
  imageUrl: String,
  tags: [String],
  status: String (enum: pending, approved, rejected, completed),
  registeredUsers: [ObjectId],
  createdAt: Date
}
```

### Registration Schema
```javascript
{
  userId: ObjectId (ref: User),
  eventId: ObjectId (ref: Event),
  status: String (enum: registered, waitlist, attended, cancelled),
  registeredAt: Date,
  notes: String
}
```

## 🔐 Security Features

- JWT-based authentication
- Password hashing with bcrypt (10 salt rounds)
- Protected routes with middleware
- Role-based authorization
- Input validation
- CORS enabled

## 🚀 Deployment

### Backend Deployment (Render/Heroku)

1. Create account on Render or Heroku
2. Create new Web Service
3. Connect your repository
4. Set environment variables
5. Deploy

### Frontend Deployment (Vercel/Netlify)

1. Create account on Vercel or Netlify
2. Connect your repository
3. Set build command: `npm run build`
4. Set publish directory: `build`
5. Deploy

### Database Deployment (MongoDB Atlas)

1. Create MongoDB Atlas account
2. Create a cluster
3. Get connection string
4. Update MONGODB_URI in backend .env

## 🔮 Future Enhancements

- Email notifications for event registrations
- AI-based event recommendations
- Mobile application (React Native)
- Real-time chat for events
- Payment integration for paid events
- Calendar integration (Google Calendar, iCal)
- Social media sharing
- Event ratings and reviews
- Advanced analytics dashboard
- Certificate generation
- QR code-based check-ins

## 📝 License

This project is licensed under the MIT License.

## 👨‍💻 Developer

**Nithin**  
B.Tech Computer Science Engineering Student

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

## 📧 Contact

For any queries or support, please contact the developer.

---

**Note:** This is an academic project developed for B.Tech final year submission.
